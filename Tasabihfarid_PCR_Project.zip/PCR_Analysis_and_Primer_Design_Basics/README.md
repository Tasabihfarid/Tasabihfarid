# PCR Analysis and Primer Design Basics

This project was created by **Tasabih Farid Ellithy**, a passionate biotechnology student at Nile University.

## 🔬 Project Overview:
This repository demonstrates basic skills in PCR analysis, primer design, and bioinformatics using Python.

## 📁 Contents:
- `primer_design.py`: A Python script to calculate the melting temperature (Tm) of a primer sequence.
- `pcr_protocol.txt`: A simple PCR protocol based on laboratory experience.
- `primers_design_notes.pdf`: Notes on how to design effective primers.
- `results/gel_image_example.png`: (Placeholder) Example image for gel electrophoresis results.

## ✨ Skills Showcased:
- PCR Protocol Writing
- Primer Tm Calculation
- Basic Python Scripting
- GitHub Project Structure

---

*This is the first version of the repository for educational and professional portfolio purposes.*

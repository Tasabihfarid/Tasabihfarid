def calculate_tm(primer):
    a_count = primer.count('A')
    t_count = primer.count('T')
    g_count = primer.count('G')
    c_count = primer.count('C')
    tm = 2 * (a_count + t_count) + 4 * (g_count + c_count)
    return tm

primer_seq = "ATGCGTACGTTAGC"
print(f"Primer: {primer_seq}")
print(f"Tm: {calculate_tm(primer_seq)} °C")
